// Gerenciamento do formulário de contato
document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contactForm');
    const formStatus = document.querySelector('.form-status');
    const formGroups = document.querySelectorAll('.form-group');
    
    // Validação de email usando regex
    const validateEmail = (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    };
    
    // Limpa os estados de erro do formulário
    const clearErrors = () => {
        formGroups.forEach(group => {
            group.classList.remove('error');
        });
        formStatus.classList.remove('success', 'error');
        formStatus.style.display = 'none';
        formStatus.textContent = '';
    };
    
    // Valida um campo específico
    const validateField = (field) => {
        const group = field.closest('.form-group');
        
        if (field.type === 'email' && field.value.trim() !== '') {
            if (!validateEmail(field.value.trim())) {
                group.classList.add('error');
                return false;
            }
        }
        
        if (field.required && field.value.trim() === '') {
            group.classList.add('error');
            return false;
        }
        
        group.classList.remove('error');
        return true;
    };
    
    // Adiciona validação em tempo real para cada campo
    formGroups.forEach(group => {
        const field = group.querySelector('input, select, textarea');
        field.addEventListener('blur', () => validateField(field));
        field.addEventListener('input', () => {
            if (group.classList.contains('error')) {
                validateField(field);
            }
        });
    });
    
    // Simula o envio do formulário
    const simulateFormSubmission = async (formData) => {
        return new Promise((resolve, reject) => {
            // Simula uma chamada de API com 50% de chance de sucesso
            setTimeout(() => {
                if (Math.random() > 0.5) {
                    resolve({
                        success: true,
                        message: 'Mensagem enviada com sucesso! Entraremos em contato em breve.'
                    });
                } else {
                    reject({
                        success: false,
                        message: 'Ocorreu um erro ao enviar a mensagem. Por favor, tente novamente.'
                    });
                }
            }, 1500);
        });
    };
    
    // Gerencia o envio do formulário
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        clearErrors();
        
        // Valida todos os campos
        let isValid = true;
        formGroups.forEach(group => {
            const field = group.querySelector('input, select, textarea');
            if (!validateField(field)) {
                isValid = false;
            }
        });
        
        if (!isValid) return;
        
        // Desabilita o botão de envio
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Enviando...';
        
        try {
            // Coleta os dados do formulário
            const formData = {
                name: contactForm.name.value.trim(),
                email: contactForm.email.value.trim(),
                subject: contactForm.subject.value,
                message: contactForm.message.value.trim()
            };
            
            // Simula o envio
            const response = await simulateFormSubmission(formData);
            
            // Mostra mensagem de sucesso
            formStatus.textContent = response.message;
            formStatus.classList.add('success');
            formStatus.style.display = 'block';
            
            // Limpa o formulário
            contactForm.reset();
            
        } catch (error) {
            // Mostra mensagem de erro
            formStatus.textContent = error.message;
            formStatus.classList.add('error');
            formStatus.style.display = 'block';
        } finally {
            // Reabilita o botão de envio
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }
    });
});