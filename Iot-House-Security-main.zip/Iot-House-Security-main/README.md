# SecuHouse 🏠🔐

Sistema web inteligente para segurança residencial baseado em IoT (Internet das Coisas).

## 📋 Sobre o Projeto

O SecuHouse é uma solução completa para monitoramento e segurança residencial, integrando dispositivos IoT em uma interface web moderna e intuitiva. Permite o gerenciamento centralizado de câmeras, sensores, alarmes e outros dispositivos de segurança.

### ✨ Características Principais

- 📱 Interface responsiva e adaptativa (mobile-first)
- 🌓 Suporte a tema claro/escuro (respeita preferências do sistema)
- ♿ Totalmente acessível (WCAG 2.1 AA)
- 🔄 Atualização em tempo real dos dispositivos
- 📊 Painel de estatísticas e análises
- 🚨 Sistema de alertas em tempo real
- 🎥 Integração com câmeras IP
- 📱 PWA (Progressive Web App) para instalação mobile

### 🛠️ Tecnologias Utilizadas

- HTML5 Semântico
- CSS3 (Grid, Flexbox, Custom Properties)
- JavaScript ES6+ (Classes, Async/Await)
- LocalStorage para persistência
- Service Workers para PWA
- WebRTC para streams de vídeo
- WebSockets para atualizações em tempo real

### 📱 Compatibilidade

- Chrome 80+
- Firefox 75+
- Safari 13.1+
- Edge 80+
- Chrome Android 80+
- Safari iOS 13.4+

## 🚀 Instalação e Uso

1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/secuhouse.git
```

2. Abra o projeto em um servidor web
```bash
# Usando Python
python -m http.server 8000

# Usando Node.js
npx serve
```

3. Acesse no navegador: `http://localhost:8000`

## 📋 Funcionalidades

### 🏠 Página Inicial
- Dashboard com visão geral do sistema
- Estatísticas em tempo real
- Gráficos de atividade
- Status dos dispositivos

### 🎥 Dispositivos
- Adicionar/remover dispositivos
- Configuração de câmeras e sensores
- Visualização em tempo real
- Controles de ativação/desativação
- Histórico de atividades

### 🚨 Alertas
- Notificações em tempo real
- Histórico de ocorrências
- Filtros por tipo e gravidade
- Configuração de regras de alerta

### 📞 Contato
- Formulário de suporte
- Chat em tempo real (em breve)
- FAQ e documentação
- Contatos de emergência

## 🤝 Contribuindo

Contribuições são bem-vindas! Sinta-se à vontade para:

1. Reportar bugs
2. Sugerir novas features
3. Enviar pull requests

## 📜 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 👥 Autores

- Desenvolvedor Principal - [Seu Nome](https://github.com/seu-usuario)
- Designer UX/UI - [Nome do Designer](https://github.com/designer)

## 🙏 Agradecimentos

- [Font Awesome](https://fontawesome.com) - Ícones
- [Google Fonts](https://fonts.google.com) - Tipografia
- [OpenStreetMap](https://www.openstreetmap.org) - Mapas
